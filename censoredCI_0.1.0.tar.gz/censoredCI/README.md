
<!-- README.md is generated from README.Rmd. Please edit that file -->

# censoredCI

<!-- badges: start -->

[![R-CMD-check](https://github.com/receptanii/censoredCI/actions/workflows/R-CMD-check.yaml/badge.svg)](https://github.com/receptanii/censoredCI/actions/workflows/R-CMD-check.yaml)
<!-- badges: end -->

The goal of censoredCI is to provide maximum likelihood estimation and
asymptotic confidence intervals for user-defined lifetime distributions
under Type-II, progressive Type-II, and progressive first-failure
censoring schemes. The package implements three main functions, ttcs()
for left, right, and double Type-II censored data, pttcs() for
progressive Type-II censored data, and pffcs() for progressive
first-failure censored data. Users provide observed failure times,
initial parameter values, relevant censoring information, and
user-defined probability density and cumulative distribution functions.
For progressive censoring models, the censoring scheme is supplied
directly by the user through a numeric vector.

The package supports classical local optimization methods such as ‘BFGS’
and ‘Brent’, together with global and population-based metaheuristic
algorithms including ‘Genetic Algorithm (GA)’, ‘Differential Evolution
(DE)’, ‘Particle Swarm Optimization (PSO)’, ‘Grey Wolf Optimizer (GWO)’,
‘Whale Optimization Algorithm (WOA)’, ‘Moth-Flame Optimization (MFO)’,
‘Sine Cosine Algorithm (SCA)’, ‘Bat Algorithm (BA)’, ‘Black Hole
Optimization (BHO)’, ‘Cuckoo Optimization Algorithm (COA)’ and ‘Clonal
Selection Algorithm (CLG)’. When automatic method selection is
requested, candidate algorithms are compared according to their attained
negative log-likelihood values and the best-performing method is
reported. The package returns parameter estimates, variance estimates,
standard errors, asymptotic confidence intervals, log-likelihood value
and the selected optimization method.

Key Features The package implements three main functions:

ttcs(): For left, right, and double Type-II censored data.

pttcs(): For progressive Type-II censored data.

pffcs(): For progressive first-failure censored data.

Users provide observed failure times, initial parameter values, relevant
censoring information, and user-defined probability density (PDF) and
cumulative distribution functions (CDF). For progressive censoring
models, the censoring scheme is supplied directly by the user through a
numeric vector.

## Installation

You can install the development version of censoredCI like so:

``` r
library(censoredCI)
```

## Examples

``` r
# Example 1: Type-II Censoring Scheme

This example shows how to perform maximum likelihood estimation with user-defined censoring schemes via ttcs():
library(censoredCI)

# 1. Data Definition
user_data <- c(0.040, 1.866, 2.385, 3.443, 0.301, 1.876, 2.481, 3.467, 0.309, 1.899,
               2.610, 3.478, 0.557, 1.911, 2.625, 3.578, 0.943, 1.912, 2.632, 3.595,
               1.070, 1.914, 2.646, 3.699, 1.124, 1.981, 2.661, 3.779, 1.248, 2.010,
               2.688, 3.924, 1.281, 2.038, 2.823, 4.035, 1.281, 2.085, 2.890, 4.121,
               1.303, 2.089, 2.902, 4.167, 1.432, 2.097, 2.934, 4.240, 1.480, 2.135,
               2.962, 4.255, 1.505, 2.154, 2.964, 4.278, 1.506, 2.190, 3.000, 4.305,
               1.568, 2.194, 3.103, 4.376, 1.615, 2.223, 3.114, 4.449, 1.619, 2.224,
               3.117, 4.485, 1.652, 2.229, 3.166, 4.570, 1.652, 2.300, 3.344, 4.602,
               1.757, 2.324, 3.376, 4.663)

sorted_data <- sort(user_data)
obs_data    <- sorted_data[1:15] 

# 2. Parameter Initial Values (Starting Points)
user_par_start <- c(.2, .2)

# 3. PDF and CDF Functions (Weibull Distribution Example)
user_pdf <- function(x, par) {
  (par[2]/par[1]) * (x/par[1])^(par[2]-1) * exp(-(x/par[1])^par[2])
}

user_cdf <- function(x, par) {
  1 - exp(-(x/par[1])^par[2])
}

# 4. Execute Inference
res <- ttcs(x = obs_data,
            par_start = user_par_start,
            pdf_f = user_pdf,
            cdf_f = user_cdf,
            r1 = 2,
            r2 = 3,
            censoring = "double",
            optimizer = "auto")

# 5. Output Results
print(res$estimates)
```

``` r
# Example 2: Progressive Type-II Censoring Scheme
This example shows how to perform maximum likelihood estimation with user-defined censoring schemes via pttcs():
library(censoredCI)

# 1. Data and Censoring Scheme Definition
user_data <- c(0.040, 1.866, 2.385, 3.443, 0.301, 1.876, 2.481, 3.467, 0.309, 1.899,
               2.610, 3.478, 0.557, 1.911, 2.625, 3.578, 0.943, 1.912, 2.632, 3.595,
               1.070, 1.914, 2.646, 3.699, 1.124, 1.981, 2.661, 3.779, 1.248, 2.010,
               2.688, 3.924, 1.281, 2.038, 2.823, 4.035, 1.281, 2.085, 2.890, 4.121,
               1.303, 2.089, 2.902, 4.167, 1.432, 2.097, 2.934, 4.240, 1.480, 2.135,
               2.962, 4.255, 1.505, 2.154, 2.964, 4.278, 1.506, 2.190, 3.000, 4.305,
               1.568, 2.194, 3.103, 4.376, 1.615, 2.223, 3.114, 4.449, 1.619, 2.224,
               3.117, 4.485, 1.652, 2.229, 3.166, 4.570, 1.652, 2.300, 3.344, 4.602,
               1.757, 2.324, 3.376, 4.663)

user_scheme <- c(2, 0, 1, 0, 0, 3, 0, 0, 1, 0, 1, 0)
sorted_data <- sort(user_data)
obs_data    <- sorted_data[1:12]

# 2. Initial Parameter Values
user_par_start <- c(2, 3)

# 3. Probability Distribution Functions
user_pdf <- function(x, par) {
  (par[2]/par[1]) * (x/par[1])^(par[2]-1) * exp(-(x/par[1])^par[2])
}

user_cdf <- function(x, par) {
  1 - exp(-(x/par[1])^par[2])
}

# 4. Model Execution
res <- pttcs(x_obs      = obs_data,
             R          = user_scheme,
             par_start  = user_par_start,
             pdf_f      = user_pdf,
             cdf_f      = user_cdf,
             opt_method = "auto")

# 5. Output Results
print(res$estimates)
```

``` r
# Example 3: Progressive First-Failure Censoring Scheme
library(censoredCI)

# 1. Data and Censoring Scheme Definition
my_data <- c(0.040, 1.866, 2.385, 3.443, 0.301, 1.876, 2.481, 3.467, 0.309, 1.899,
             2.610, 3.478, 0.557, 1.911, 2.625, 3.578, 0.943, 1.912, 2.632, 3.595,
             1.070, 1.914, 2.646, 3.699, 1.124, 1.981, 2.661, 3.779, 1.248, 2.010,
             2.688, 3.924, 1.281, 2.038, 2.823, 4.035, 1.281, 2.085, 2.890, 4.121,
             1.303, 2.089, 2.902, 4.167, 1.432, 2.097, 2.934, 4.240, 1.480, 2.135,
             2.962, 4.255, 1.505, 2.154, 2.964, 4.278, 1.506, 2.190, 3.000, 4.305,
             1.568, 2.194, 3.103, 4.376, 1.615, 2.223, 3.114, 4.449, 1.619, 2.224,
             3.117, 4.485, 1.652, 2.229, 3.166, 4.570, 1.652, 2.300, 3.344, 4.602,
             1.757, 2.324, 3.376, 4.663)

user_scheme <- c(2, 0, 1, 0, 0, 3, 0, 0, 1, 0, 1, 0)
sorted_data <- sort(my_data)
obs_data    <- sorted_data[1:12]
user_par_start <- c(2, 3)

# 2. PDF and CDF Functions
user_pdf <- function(x, par) {
  (par[2]/par[1]) * (x/par[1])^(par[2]-1) * exp(-(x/par[1])^par[2])
}

user_cdf <- function(x, par) {
  1 - exp(-(x/par[1])^par[2])
}

# 3. Run the Progressive First Failure Censoring Inference
result <- pffcs(x_obs      = obs_data,
                R          = user_scheme,
                par_start  = user_par_start,
                pdf_f      = user_pdf,
                cdf_f      = user_cdf,
                opt_method = "auto")

# 4. Output Results
print(result$estimates)
```

What is special about using `README.Rmd` instead of just `README.md`?
You can include R chunks like so:

You’ll still need to render `README.Rmd` regularly, to keep `README.md`
up-to-date. `devtools::build_readme()` is handy for this.

In that case, don’t forget to commit and push the resulting figure
files, so they display on GitHub and CRAN.
